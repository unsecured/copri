#!/bin/sh
# copri, Attacking RSA by factoring coprimes
# License: GNU Lesser General Public License (LGPL), version 3 or later
# See the lgpl.txt file in the root directory or <https://www.gnu.org/licenses/lgpl>.

./test-array
./test-arrayio
./test-twopower
./test-prod
./test-gcdppippo
./test-gcdppgpple
./test-appendcb
./test-split
./test-cbextend
./test-cbmerge
./test-cb
./test-findfactor